// SCORM Parent
let SD = window.parent;

// Elements
let displayTime = document.getElementById('displayTime');
let displayStatus = document.getElementById('displayStatus');
let displayPassed = document.getElementById('displayPassed');
let displayFailed = document.getElementById('displayFailed');
let displayReset = document.getElementById('displayReset');
let displaySuspendData = document.getElementById('displaySuspendData');
let scormData = document.getElementById('setScormData');
let scormScore = document.getElementById('setScormScore');

function getTime(){
    displayTime.innerHTML = "Total Waktu Yang Dihabiskan Di Course Ini: <strong>"+getOverallTime()+"</strong><br/>Waktu Yang Dihabiskan Di Session Ini: <strong>"+getSessionTime()+"</strong>";
}
function getStatus(){
    // alert(SD.GetStatus()); -> get status via alert
    displayStatus.innerHTML = decodeStatus(SD.GetStatus()); // get status (string) ke html/webpage di id displayStatus
}

function setPassed(){
    SD.SetPassed(); // status ke set menjadi "1"
    displayPassed.innerHTML = "Selamat Anda Telah Lulus Course Ini";
}
function setFailed(){
    SD.SetFailed();
    displayFailed.innerHTML = "Maaf Anda Gagal";
}
function resetStatus(){
    SD.ResetStatus();
    displayReset.innerHTML = "Status Ter Reset";
}
function setSuspendData(){
    let scormData = document.getElementById("setScormData");
    SD.SetDataChunk(scormData.value);
    alert('Data Chunk Tersimpan');
}

function getSuspendData(){
    displaySuspendData.innerHTML = SD.GetDataChunk();
}

function setScore(){
    let updatedNum = parseInt(scormScore.value);
    SD.SetScore(updatedNum,10,0);
    // jika score > 7 , set status jadi 1(passed),selain itu set 3(fail)
    if(updatedNum >= 7){
        SD.SetPassed();
    }else{
        SD.SetFailed();
    }
    alert("Score Telah Diset Menjadi"+updatedNum);
}

// memberi variable pada status
function decodeStatus(intStatus){
    var stringStatus = "";
    switch (intStatus) {
        case 1:
            stringStatus = "Lulus";
            break;
        case 2:
            stringStatus = "Belum Selesai";
            break;
        case 3:
            stringStatus = "Failed";
            break;
        case 4:
            stringStatus = "Unknown / Not Set";
            break;
        default:
            break;
    }
    return stringStatus;
}

// get time
function getOverallTime(){
    var msOverall = SD.GetSessionAccumulatedTime() + SD.GetPreviouslyAccumulatedTime();
    // GetSessionAccumulatedTime() -> Mengambil waktu yang dihabiskan di 1 session
    // GerPreviouslyAccumulatedTime() -> 	Mengambil waktu di session sebelumnya
    var timeSpentOverall = "";
    timeSpentOverall += Math.round((msOverall / (1000*60*60)) % 24)+' jam,';
    timeSpentOverall += Math.round((msOverall / (1000*60)) % 60)+' menit,';
    timeSpentOverall += Math.round((msOverall / 1000) % 60)+' detik.';

    return timeSpentOverall;
}

function getSessionTime(){
    var msOverall = SD.GetSessionAccumulatedTime();
    var timeSpentOverall = "";
    timeSpentOverall += Math.round((msOverall / (1000*60*60)) % 24)+' jam,';
    timeSpentOverall += Math.round((msOverall / (1000*60)) % 60)+' menit,';
    timeSpentOverall += Math.round((msOverall / 1000) % 60)+' detik.';

    return timeSpentOverall;
}